//
//  PLMediaMasterPKViewController.h
//  PLMediaStreamingKitDemo
//
//  Created by suntongmian on 16/8/28.
//  Copyright © 2016年 Pili. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PLMediaMasterPKViewController : UITableViewController

@end
