//
//  PLMediaViewerPKViewController.h
//  PLMediaStreamingKitDemo
//
//  Created by suntongmian on 16/8/28.
//  Copyright © 2016年 Pili. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface PLMediaViewerPKViewController : UIViewController

@property (nonatomic, assign) PLMediaUserPKType userType;
@property (nonatomic, strong) NSString *roomName;
@property (nonatomic, strong) NSString *roomToken;
@property (nonatomic, strong) NSString *popStr;

@end
