//
//  PLMediaMasterPKViewController.m
//  PLMediaStreamingKitDemo
//
//  Created by suntongmian on 16/8/28.
//  Copyright © 2016年 Pili. All rights reserved.
//

#import "PLMediaMasterPKViewController.h"
#import "PLMediaChiefPKViewController.h"
#import "PLMediaSettingPKViewController.h"
#import "PLMediaViewerPKViewController.h"
#import "PlayListViewController.h"
#import "PLPixelBufferProcessor.h"

@interface PLMediaMasterPKViewController ()

@property (nonatomic, strong) NSString *userID;

@property (nonatomic, strong) NSString *roomID;
@property (nonatomic, strong) NSString *roomName;
@property (nonatomic, strong) NSString *roomToken;
@property NSArray *objects;
@property (nonatomic, strong) UIAlertController *alertCtrl;

@end

@implementation PLMediaMasterPKViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.title = @"PLMediaStreamingKitPKDemo";
    
    self.objects = @[@"主播", @"副主播", @"连麦观众",@"观看直播"];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStylePlain target:self action:@selector(settingButtonClick:)];
    self.navigationItem.rightBarButtonItem = item;
    
}


- (void)viewWillAppear:(BOOL)animated {
    self.clearsSelectionOnViewWillAppear = self.splitViewController.isCollapsed;
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)settingButtonClick:(id)sender
{
    PLMediaSettingPKViewController *settingViewController = [[PLMediaSettingPKViewController alloc] init];
    [self.navigationController pushViewController:settingViewController animated:YES];
}



#pragma mark - Table View

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.objects.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    cell.textLabel.text = self.objects[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//    self.roomName = [userDefaults objectForKey:@"PLMediaPKRoomName"];
    if ((!self.roomName || [self.roomName isEqualToString:@""])&&(indexPath.row ==0)) {
        [self directAction];
        return;
    }
    
    if (indexPath.row == 0) {

        return;
    }
    if (indexPath.row == 3) {
        PlayListViewController *ctrl = [[PlayListViewController alloc] init];
        [self.navigationController pushViewController:ctrl animated:YES];
        
        return;
    }
    
    PLMediaViewerPKViewController *controller = [[PLMediaViewerPKViewController alloc] init];
    controller.userType = indexPath.row;
    controller.navigationItem.leftItemsSupplementBackButton = YES;
    controller.roomName = self.roomName;
    [self presentViewController:controller animated:YES completion:nil];
}




//提醒主播输入房间名字
-(void)directAction{
    
    self.alertCtrl = [UIAlertController alertControllerWithTitle: @"输入房间名" message:nil preferredStyle:UIAlertControllerStyleAlert];
    WS(ws);
    UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"点击了取消按钮");
    }];
    
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        ws.roomID = [[[self.alertCtrl textFields] firstObject] text];
        [ws createRoom];//创建房间
        
    }];
    [self.alertCtrl addAction:cancleAction];
    [self.alertCtrl addAction:defaultAction];
    
    [self.alertCtrl addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"请输入房间名";
    }];
    
    [self presentViewController:self.alertCtrl animated:YES completion:nil];
    
}

-(void)createRoom{
    
    NSLog(@"---roomName --- %@",self.roomID);
    WS(ws);
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
//    NSString *createRoomReq = [NSString stringWithFormat:@"http://192.168.3.78:8080/Video1.1/creatRoom.json?%@",self.roomID];
    NSString *createRoomReq = [NSString stringWithFormat:@"http://192.168.3.78:8080/saas/creatVideoRoom?ownername=user01&room=%@",self.roomID];
    
    NSURL *domainURL = [NSURL URLWithString:createRoomReq];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:domainURL];
    request.HTTPMethod = @"POST";
    request.timeoutInterval = 10;
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error != nil || response == nil || data == nil) {
            NSLog(@"get streamjson faild, %@, %@, %@", error, response, data);
            return ;
        }
        
        id resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        NSLog(@"创建房间-----%@",resultDic);
        
        ws.roomName =  resultDic[0][@"RoomName"];
        ws.roomToken = resultDic[0][@"RoomToken"];
        
        PLMediaChiefPKViewController *directCtrl = [[PLMediaChiefPKViewController alloc] init];
        directCtrl.roomName = ws.roomName;
        directCtrl.roomToken = ws.roomToken;
        [ws.navigationController pushViewController:directCtrl animated:YES];
    }];
    [task resume];
    
}


@end
