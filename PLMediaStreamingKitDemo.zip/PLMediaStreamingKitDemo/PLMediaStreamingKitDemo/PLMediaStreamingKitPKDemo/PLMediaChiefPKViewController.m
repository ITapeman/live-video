//
//  PLMediaChiefPKViewController.m
//  PLMediaStreamingKitDemo
//
//  Created by suntongmian on 16/8/28.
//  Copyright © 2016年 Pili. All rights reserved.
//

#import "PLMediaChiefPKViewController.h"
#import "PLMediaStreamingKit.h"
#import "PLPlayerKit.h"
#import "PLPixelBufferProcessor.h"

const static char *streamStateNames[] = {
    "Unknow",
    "Connecting",
    "Connected",
    "Disconnecting",
    "Disconnected",
    "Error"
};

const static char *rtcStateNames[] = {
    "Unknown",
    "ConferenceStarted",
    "ConferenceStopped"
};

@interface PLMediaChiefPKViewController ()<PLMediaStreamingSessionDelegate, PLPlayerDelegate, AVCaptureVideoDataOutputSampleBufferDelegate>

@property (nonatomic, strong) UIButton *actionButton;//推流
@property (nonatomic, strong) UIButton *backButton;//返回按钮
@property (nonatomic, strong) UIButton *muteButton;//静音
@property (nonatomic, strong) UIButton *conferenceButton;//连麦按钮
@property (nonatomic, strong) UIButton *changeCameraStateButton; // 切换前置／后置摄像头

@property (nonatomic, strong) PLMediaStreamingSession *session;
@property (nonatomic, strong) PLPixelBufferProcessor *pixelBufferProcessor;

@property (nonatomic, assign) NSUInteger viewSpaceMask;

@property (nonatomic, strong) NSMutableDictionary *userViewDictionary;
@property (nonatomic, strong) NSString *    userID;
@property (nonatomic, strong) PLStream *stream;


@end

@implementation PLMediaChiefPKViewController

#pragma mark - Managing the detail item

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.navigationController setNavigationBarHidden:YES];
    self.userViewDictionary = [[NSMutableDictionary alloc] initWithCapacity:3];
    
    if (!self.roomName) {
        [self showAlertWithMessage:@"请先在设置界面设置您的房间名" completion:nil];
        return;
    }
    
    NSLog(@"直播");
    
    
    [self setupUI];
    [self initStreamingSession];
    [self postPlay];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleApplicationDidEnterBackground:)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];
}

- (void)setupUI
{
    self.backButton = [[UIButton alloc] initWithFrame:CGRectMake(20, 20, 44, 44)];
    [self.backButton setTitle:@"返回" forState:UIControlStateNormal];
    [self.backButton addTarget:self action:@selector(backButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.backButton];
    
    self.actionButton = [[UIButton alloc] initWithFrame:CGRectMake(20, 90, 66, 30)];
    [self.actionButton setTitle:@"推流" forState:UIControlStateNormal];
    [self.actionButton setTitle:@"暂停" forState:UIControlStateSelected];
    [self.actionButton.titleLabel setFont:[UIFont systemFontOfSize:22]];
    [self.actionButton setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
    [self.actionButton setTitleColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:0.1] forState:UIControlStateDisabled];
    [self.actionButton addTarget:self action:@selector(actionButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.actionButton];
    self.actionButton.hidden = YES;
    
    self.muteButton = [[UIButton alloc] initWithFrame:CGRectMake(116, 90, 66, 30)];
    [self.muteButton setTitle:@"静音" forState:UIControlStateNormal];
    [self.muteButton.titleLabel setFont:[UIFont systemFontOfSize:22]];
    [self.muteButton setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
    [self.muteButton setTitleColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:0.1] forState:UIControlStateDisabled];
    [self.muteButton addTarget:self action:@selector(muteButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.muteButton];
    
    self.conferenceButton = [[UIButton alloc] initWithFrame:CGRectMake(196, 90, 66, 30)];
    [self.conferenceButton setTitle:@"连麦" forState:UIControlStateNormal];
    [self.conferenceButton setTitle:@"停止" forState:UIControlStateSelected];
    [self.conferenceButton.titleLabel setFont:[UIFont systemFontOfSize:22]];
    [self.conferenceButton setTitleColor:[UIColor blueColor] forState:UIControlStateHighlighted];
    [self.conferenceButton setTitleColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:0.1] forState:UIControlStateDisabled];
    [self.conferenceButton addTarget:self action:@selector(directConferenceButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.conferenceButton];
    self.conferenceButton.hidden = YES;
    
    self.changeCameraStateButton = [[UIButton alloc] initWithFrame:CGRectMake(300, 90, 45, 35)];
    [self.changeCameraStateButton setBackgroundImage:[UIImage imageNamed:@"rotate.png"] forState:UIControlStateNormal];
    [self.changeCameraStateButton addTarget:self action:@selector(changeCameraStateButtonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.changeCameraStateButton];
}

- (void)initStreamingSession
{
    PLVideoCaptureConfiguration *videoCaptureConfiguration = [PLVideoCaptureConfiguration defaultConfiguration];
    videoCaptureConfiguration.position = AVCaptureDevicePositionFront;
    
    self.session = [[PLMediaStreamingSession alloc]
                    initWithVideoCaptureConfiguration:videoCaptureConfiguration
                    audioCaptureConfiguration:[PLAudioCaptureConfiguration defaultConfiguration]
                    videoStreamingConfiguration:[PLVideoStreamingConfiguration defaultConfiguration]
                    audioStreamingConfiguration:[PLAudioStreamingConfiguration defaultConfiguration]
                    stream:nil];
    self.session.delegate = self;
    self.session.captureDevicePosition = videoCaptureConfiguration.position;
//    self.session.fillMode = PLVideoFillModePreserveAspectRatio;//视频的填充方式
    
    [self.session setBeautifyModeOn:YES];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        self.session.previewView.frame = CGRectMake(0 , 0, screenWidth, screenHeight);
        [self.view insertSubview:self.session.previewView atIndex:0];
    });
    
    self.actionButton.hidden = NO;
    self.conferenceButton.hidden = NO;

    //#您需要通过 App 的业务服务器去获取连麦需要的 userID 和 roomToken，此处为了 Demo 演示方便，可以在获取后直接设置下面这两个属性
    self.userID = @"user01";
}


////发起直播请求
-(void)postPlay{
    
    //显示加载状态
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    NSURL *domainURL = [NSURL URLWithString:@"http://192.168.3.78:8080/saas/pushURL?name=user01"];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:domainURL];
    request.HTTPMethod = @"POST";
    request.timeoutInterval = 10;
    WS(ws);
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        
        if (error != nil || response == nil || data == nil) {
            NSLog(@"get streamjson faild, %@, %@, %@", error, response, data);
            return ;
        }
        id resultDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        ws.pushStr = resultDic[0][@"TLURL"];
        ws.streamNameDic = resultDic[0][@"StreamName"];
        ws.roomName = ws.roomName;
        ws.roomToken = ws.roomToken;
        
        if (error != nil || resultDic == nil) {
            NSLog(@"json decode error %@", error);
            return;
        }
    }];
    [task resume];
}



- (void)backButtonClick
{
    [self.session.previewView removeFromSuperview];
    
    self.session.delegate = nil;
    [self.session destroy];
    self.session = nil;

    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self dismissViewControllerAnimated:YES completion:nil];
    
    [self.navigationController setNavigationBarHidden:NO];
}

- (void)actionButtonClick
{
    if (!self.session.isStreamingRunning) {
        self.actionButton.enabled = NO;
        if (!self.session.stream) {
            self.session.stream = self.stream;
        }
        
        [self.session startStreamingWithPushURL:[NSURL URLWithString:self.pushStr] feedback:^(PLStreamStartStateFeedback feedback) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.actionButton.enabled = YES;
                if (feedback == PLStreamStartStateSuccess) {
                    self.actionButton.selected = YES;
                }
                else {
                    [self showAlertWithMessage:[NSString stringWithFormat:@"推流失败! feedback is %lu", (unsigned long)feedback] completion:nil];
                }
            });
        }];
    } else {
        [self.session stopStreaming];
        self.actionButton.selected = NO;
    }
}

- (void)muteButtonClick:(id)sender
{
    self.muteButton.selected = !self.muteButton.selected;
    self.session.muted = self.muteButton.selected;
}

- (void)kickoutButtonClick:(id)sender {
    UIButton *button = (UIButton *)sender;
    UIView *view = button.superview;
    for (NSString *userID in self.userViewDictionary.allKeys) {
        if ([self.userViewDictionary objectForKey:userID] == view) {
            [self.session kickoutUserID:userID];
            break;
        }
    }
}

- (void)directConferenceButtonClick
{
    
    NSLog(@"roomToken --- %@,roomName --- %@,userID-----%@",self.roomToken,self.roomName,self.userID);
    self.conferenceButton.enabled = NO;
    if (!self.conferenceButton.selected) {
        [self.session startConferenceWithRoomName:self.roomName userID:self.userID roomToken:self.roomToken rtcConfiguration:[PLRTCConfiguration defaultConfiguration]];
        NSDictionary *option = @{kPLRTCRejoinTimesKey:@(2), kPLRTCConnetTimeoutKey:@(3000)};
        self.session.rtcOption = option;
        self.session.rtcMinVideoBitrate= 300 * 1000;
        self.session.rtcMaxVideoBitrate= 800 * 1000;
        
        // 连麦的画面在主画面中的位置和大小(推出去的流的位置，并非预览位置)(观众看到的副主播在主播端的位置)
        self.session.rtcMixOverlayRectArray = [NSArray arrayWithObjects:[NSValue valueWithCGRect:CGRectMake(screenWidth/3.0, screenHeight/3.0, screenWidth/3.0, screenHeight/3.0)], nil];
    }
    else {
        [self.session stopConference];
    }
    return;
}

// 切换前置／后置摄像头
- (void)changeCameraStateButtonClick {
    [self.session toggleCamera];
}

- (void)muteButtonClick
{
    self.muteButton.selected = !self.muteButton.selected;
    self.session.muted = self.muteButton.selected;
}


- (void)showAlertWithMessage:(NSString *)message completion:(void (^)(void))completion
{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"错误" message:message preferredStyle:UIAlertControllerStyleAlert];
    [controller addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        if (completion) {
            completion();
        }
    }]];
    [self presentViewController:controller animated:YES completion:nil];
}


- (void)dealloc
{
    NSLog(@"PLMediaChiefViewController dealloc");
}

- (void)requestStreamJsonWithCompleted:(void (^)(NSDictionary *json))handler
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://pili-demo.qiniu.com/api/stream/%@", self.roomName]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    request.HTTPMethod = @"POST";
    request.timeoutInterval = 10;
    
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error != nil || response == nil || data == nil) {
            NSLog(@"get streamjson faild, %@, %@, %@", error, response, data);
            dispatch_async(dispatch_get_main_queue(), ^{
                handler(nil);
            });
            return;
        }
        
        NSDictionary *streamJSON = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
        if (error != nil || streamJSON == nil) {
            NSLog(@"json decode error %@", error);
            dispatch_async(dispatch_get_main_queue(), ^{
                handler(nil);
            });
            return;
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            handler(streamJSON);
        });
        
    }];
    [task resume];
}

- (void)requestTokenWithUserID:(NSString *)userID completed:(void (^)(NSString *token))handler
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://pili-demo.qiniu.com/api/room/%@/user/%@/token", self.roomName, userID]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    request.HTTPMethod = @"POST";
    request.timeoutInterval = 10;
    
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error != nil || response == nil || data == nil) {
            NSLog(@"get token faild, %@, %@, %@", error, response, data);
            dispatch_async(dispatch_get_main_queue(), ^{
                handler(nil);
            });
            return;
        }
        
        NSString *token = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        dispatch_async(dispatch_get_main_queue(), ^{
            handler(token);
        });
    }];
    [task resume];
}

#pragma mark - observer

- (void)handleApplicationDidEnterBackground:(NSNotification *)notification {
    if (self.session.isRtcRunning) {
        [self.session stopConference];
        self.conferenceButton.enabled = YES;
    }
}



- (void)showAlertWithRTC:(NSString *)message
{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"错误" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        //不连麦
    }];
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
       //发起连麦的请求
        [self directConferenceButtonClick];
    }];
    [controller addAction:cancleAction];
    [controller addAction:defaultAction];
    [self presentViewController:controller animated:YES completion:nil];
}



#pragma mark - 推流回调

- (void)mediaStreamingSession:(PLMediaStreamingSession *)session streamStateDidChange:(PLStreamState)state {
    NSString *log = [NSString stringWithFormat:@"Stream State: %s", streamStateNames[state]];
    NSLog(@"%@", log);
    
    if (state == PLStreamStateConnected) {
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showAlertWithRTC:) name:@"RTC" object:nil];
    }
    
}

- (void)mediaStreamingSession:(PLMediaStreamingSession *)session didDisconnectWithError:(NSError *)error {
    NSLog(@"error: %@", error);
    self.actionButton.enabled = YES;
    [self showAlertWithMessage:[NSString stringWithFormat:@"Error code: %ld, %@", (long)error.code, error.localizedDescription] completion:nil];
}


/// @abstract 当开始推流时，会每间隔 3s 调用该回调方法来反馈该 3s 内的流状态，包括视频帧率、音频帧率、音视频总码率
- (void)mediaStreamingSession:(PLMediaStreamingSession *)session streamStatusDidUpdate:(PLStreamStatus *)status {
    NSLog(@"%@", status);
}






#pragma mark - 连麦回调
- (void)mediaStreamingSession:(PLMediaStreamingSession *)session rtcStateDidChange:(PLRTCState)state {
    NSString *log = [NSString stringWithFormat:@"RTC State: %s", rtcStateNames[state]];
    NSLog(@"%@", log);
    
    if (state == PLRTCStateConferenceStarted) {
        self.conferenceButton.selected = YES;
    } else {
        self.conferenceButton.selected = NO;
        self.viewSpaceMask = 0;
    }
    self.conferenceButton.enabled = YES;
}

/// @abstract 因产生了某个 error 的回调
- (void)mediaStreamingSession:(PLMediaStreamingSession *)session rtcDidFailWithError:(NSError *)error {
    NSLog(@"error: %ld,%@", (long)error.code, error.localizedDescription);
    self.conferenceButton.enabled = YES;
    [self showAlertWithMessage:[NSString stringWithFormat:@"Error code: %ld, %@", (long)error.code, error.localizedDescription] completion:^{
    }];
}

//连麦时，将对方视频渲染到 remoteView 后的回调，可将 remoteView 添加到合适的 View 上将其显示出来。本接口在主队列中回调。
- (void)mediaStreamingSession:(PLMediaStreamingSession *)session userID:(NSString *)userID didAttachRemoteView:(UIView *)remoteView {
    
    
    if (!(self.viewSpaceMask & 0x01)) {
        self.viewSpaceMask |= 0x01;
    } else if (!(self.viewSpaceMask & 0x02)) {
        self.viewSpaceMask |= 0x02;
    }else {
        //超出 3 个连麦观众，不再显示。
        return;
    }
    
    //主播端显示的连麦用户的画面（remoteView）副主播显示在主播预览界面的位置
    remoteView.frame = CGRectMake(screenWidth/3.0*2-10, screenHeight/3.0*2-10, screenWidth/3.0, screenHeight/3.0);
    remoteView.clipsToBounds = YES;
    [self.view addSubview:remoteView];
    
    UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(screenWidth * 0.4 - 60, 0, 40, 20)];
    [button setTitle:@"踢出" forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:14]];
    [button addTarget:self action:@selector(kickoutButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [remoteView addSubview:button];
    
    [self.userViewDictionary setObject:remoteView forKey:userID];
    [self.view bringSubviewToFront:self.conferenceButton];
}

- (void)mediaStreamingSession:(PLMediaStreamingSession *)session userID:(NSString *)userID didDetachRemoteView:(UIView *)remoteView {
    if (![self.userViewDictionary objectForKey:userID]) {
        return;
    }
    [remoteView removeFromSuperview];
    [self.userViewDictionary removeObjectForKey:userID];
    self.viewSpaceMask = 0;
}

- (void)mediaStreamingSession:(PLMediaStreamingSession *)session didKickoutByUserID:(NSString *)userID {
    [self showAlertWithMessage:@"您被主播踢出房间了！" completion:^{
        [self backButtonClick];
    }];
}





#pragma mark -- 限制控制器方向为 右横屏

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    if (UIInterfaceOrientationLandscapeRight == toInterfaceOrientation) {
        self.session.videoOrientation = AVCaptureVideoOrientationLandscapeRight;
    } else {
        self.session.videoOrientation = AVCaptureVideoOrientationLandscapeLeft;
    }
}

- (BOOL)shouldAutorotate {
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskLandscapeRight | UIInterfaceOrientationMaskLandscapeLeft;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    return UIInterfaceOrientationLandscapeRight;
}

@end
