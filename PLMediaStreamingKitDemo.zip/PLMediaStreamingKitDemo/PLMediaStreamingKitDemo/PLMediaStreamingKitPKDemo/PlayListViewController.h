//
//  PlayListViewController.h
//  PLMediaStreamingKitDemo
//
//  Created by Apple on 2017/2/9.
//  Copyright © 2017年 NULL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayListViewController : UIViewController

@property (nonatomic, assign) PLMediaUserPKType userType;
@property(nonatomic ,strong)NSMutableArray *dataSource;
@property(nonatomic ,strong)UICollectionView *myCollection;
@property (nonatomic, strong) NSString *roomName;

-(void)setUpCollection;

@end
