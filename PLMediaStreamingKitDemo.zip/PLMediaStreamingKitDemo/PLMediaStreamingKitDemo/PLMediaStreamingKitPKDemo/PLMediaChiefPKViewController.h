//
//  PLMediaChiefPKViewController.h
//  PLMediaStreamingKitDemo
//
//  Created by suntongmian on 16/8/28.
//  Copyright © 2016年 Pili. All rights reserved.
//

//主播端

#import <UIKit/UIKit.h>

@interface PLMediaChiefPKViewController : UIViewController

@property (nonatomic, strong) NSString *roomName;
@property (nonatomic, strong) NSString *roomToken;
@property (nonatomic, strong) NSString *pushStr;
@property(nonatomic, strong)NSMutableDictionary *streamNameDic;

@end
