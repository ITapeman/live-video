//
//  PlayListViewController.m
//  PLMediaStreamingKitDemo
//
//  Created by Apple on 2017/2/9.
//  Copyright © 2017年 NULL. All rights reserved.
//

#import "NowStreamCell.h"
#import "PLMediaViewerPKViewController.h"

#import "PlayListViewController.h"

@interface PlayListViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property(nonatomic,assign)NSInteger indexPathRow;

@end

static NSString *cellID = @"cellId";

@implementation PlayListViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"=========直播列表页面");
    
    //配置collection view
    [self setUpCollection];
    //请求直播列表信息
    [self getPlay];
    
    
}

-(void)setUpCollection{
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.headerReferenceSize = CGSizeMake(self.view.bounds.size.width, 100);
    layout.itemSize = CGSizeMake(screenWidth/2-30, 150);
    layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    
    //配置collectionView
    self.myCollection = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    self.myCollection.center = CGPointMake(screenWidth/2, screenHeight/2);
    self.myCollection.backgroundColor = [UIColor whiteColor];
    
    [_myCollection registerClass:[NowStreamCell class] forCellWithReuseIdentifier:@"cellID"];
    
    self.myCollection.delegate = self;
    self.myCollection.dataSource = self;
    [self.view addSubview:self.myCollection];
}
//获取播放列表
-(void)getPlay{
    
    //显示加载状态
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    NSURL *domainURL = [NSURL URLWithString:@"http://192.168.3.78:8080/saas/showAllStream"];
    
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:domainURL];
    request.HTTPMethod = @"POST";
    request.timeoutInterval = 10;
    WS(ws);
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        
        if (error != nil || response == nil || data == nil) {
            NSLog(@"get streamjson faild, %@, %@, %@", error, response, data);
            return ;
        }
        
        //暂停显示加载的状态
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        id result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
        NSLog(@"showAllStream ---- %@",result);
        
        ws.dataSource = result;
        [ws.myCollection reloadData];
        [ws.myCollection layoutSubviews];
        
        if (error != nil || result == nil) {
            NSLog(@"json decode error %@", error);
            return;
        }
    }];
    [task resume];
}

//观看直播
-(void)getCLickPlay:(NSString *)popStreamName{
    
    //显示加载状态
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    NSString *domainStr = [NSString stringWithFormat:@"http://192.168.3.78:8080/saas/liveAddress?keyA=%@&username=%@",popStreamName,@"person01"];
//    NSString *playParamStr = [domainStr stringByAppendingFormat:@"%@", popStreamName];//拼接上一级页面传过来的streamname
    NSURL *playURL = [NSURL URLWithString:domainStr];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:playURL];
    request.HTTPMethod = @"POST";
    WS(ws);
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (error != nil || response == nil || data == nil) {
            NSLog(@"get streamjson faild, %@, %@, %@", error, response, data);
            return ;
        }
        //暂停显示加载的状态
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        id result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
        
        NSLog(@"result----%@",result);
        
        PLMediaViewerPKViewController *controller = [[PLMediaViewerPKViewController alloc] init];
        controller.userType = PLMediaUserPKTypeViewer;
        controller.navigationItem.leftItemsSupplementBackButton = YES;
        controller.roomName = result[0][@"RoomName"];
        controller.popStr = result[0][@"BFURL"];
        controller.roomToken = result[0][@"RoomToken"];
        [ws.navigationController pushViewController:controller animated:YES];
        
        
        if (error != nil || result == nil) {
            NSLog(@"json decode error %@", error);
            return;
        }
    }];
    [task resume];
    
}











#warning collectionView Delegate
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return  self.dataSource.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NowStreamCell *cell = (NowStreamCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cellID" forIndexPath:indexPath];
    NSDictionary *dic = self.dataSource[indexPath.row];
    
    NSLog(@"----%@",dic[@"VideoCover"]);
    
    
    
    if ([dic[@"VideoState"] isEqual:@1]) {
        //表示正在直播
        cell.videoState.text = [NSString stringWithFormat:@"%@",dic[@"StreamName"]];
        cell.streamName.text = [NSString stringWithFormat:@"%@",dic[@"VideoState"]];
        
        
        cell.backgroundColor = [UIColor yellowColor];
        NSURL *imgURL = [NSURL URLWithString:dic[@"VideoCover"]];
        UIImage *cellImg = [UIImage imageWithData:[NSData dataWithContentsOfURL:imgURL]];
        cell.VideoCover = [[UIImageView alloc] initWithImage:cellImg highlightedImage:[UIImage imageNamed:@"doctor.png"]];
        cell.VideoCover = [[UIImageView alloc] initWithImage:cellImg];

    }else{
        cell.backgroundColor = [UIColor lightGrayColor];
    }
    
    return cell;
}
//设置每个item的大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    return CGSizeMake(screenWidth/2-30, 150);
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    self.indexPathRow = indexPath.row;
    
    NSDictionary *curDic = self.dataSource[indexPath.row];
    [self getCLickPlay:curDic[@"StreamName"]];
}






- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
