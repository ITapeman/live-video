//
//  NowStreamCell.m
//  RM
//
//  Created by Apple on 2017/1/19.
//  Copyright © 2017年 Apple. All rights reserved.
//

#import "NowStreamCell.h"

@implementation NowStreamCell

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame: frame];
    if (self) {
        
        _VideoCover = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height-40)];
        [self.contentView addSubview:_VideoCover];
        
        _videoState = [[UILabel alloc] initWithFrame:CGRectMake(0, frame.size.height-60, frame.size.width, 30)];
        _videoState.textAlignment = NSTextAlignmentCenter;
        _videoState.textColor = [UIColor blackColor];
        _videoState.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_videoState];
        
        
        _streamName = [[UILabel alloc] initWithFrame:CGRectMake(0, frame.size.height-30, frame.size.width, 30)];
        _streamName.textAlignment = NSTextAlignmentCenter;
        _streamName.textColor = [UIColor blackColor];
        _streamName.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_streamName];
    }
    return self;
}


@end
