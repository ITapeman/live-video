//
//  PLMediaSettingViewController.m
//  PLMediaStreamingKitDemo
//
//  Created by lawder on 16/7/18.
//  Copyright © 2016年 NULL. All rights reserved.
//

#import "PLMediaSettingViewController.h"

@interface PLMediaSettingViewController ()

@property (nonatomic, strong) IBOutlet UITextField *textField;
@property (nonatomic, strong) IBOutlet UISegmentedControl *segmentControl;
@property (nonatomic, strong) IBOutlet UILabel *versionLabel;

@end

@implementation PLMediaSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *roomName = [userDefaults objectForKey:@"PLMediaRoomName"];
    self.textField.text = roomName;
    self.segmentControl.selectedSegmentIndex = [userDefaults integerForKey:@"PLMediaAudioOnly"];
    
    NSDictionary *info= [[NSBundle mainBundle] infoDictionary];
    self.versionLabel.text = [NSString stringWithFormat:@"版本：%@", info[@"CFBundleVersion"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)saveButtonClick:(id)sender
{
    if (!self.textField.text  || [self.textField.text isEqualToString:@""]) {
        [self showAlertWithMessage:@"房间名不能为空"];
        return;
    }
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:self.textField.text forKey:@"PLMediaRoomName"];
    [userDefaults setInteger:self.segmentControl.selectedSegmentIndex forKey:@"PLMediaAudioOnly"];
    [userDefaults synchronize];
    
    [self showAlertWithMessage:@"保存成功"];
}

- (void)showAlertWithMessage:(NSString *)message
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] < 8.0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
    }
    else {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"提示" message:message preferredStyle:UIAlertControllerStyleAlert];
        [controller addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:controller animated:YES completion:nil];
    }
}

@end
