//
//  PLMediaSettingViewController.h
//  PLMediaStreamingKitDemo
//
//  Created by lawder on 16/7/18.
//  Copyright © 2016年 NULL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PLMediaSettingViewController : UIViewController

@end
